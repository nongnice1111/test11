#!/bin/bash
echo "=== [เครื่อง 3] Deploy Target Health Check ==="

command -v docker >/dev/null 2>&1 && echo "✓ Docker ติดตั้งแล้ว" || echo "✗ ไม่มี Docker"
systemctl is-active --quiet docker && echo "✓ Docker กำลังรัน" || echo "✗ Docker ไม่ทำงาน"
docker compose version >/dev/null 2>&1 && echo "✓ Docker Compose ติดตั้งแล้ว" || echo "✗ ไม่มี Docker Compose"

[ -d /app ] && echo "✓ /app มีอยู่" || echo "✗ ไม่มี /app (pipeline จะ fail)"
[ -f /app/docker-compose.yml ] && echo "✓ /app/docker-compose.yml มีอยู่" || echo "✗ ไม่มี docker-compose.yml ใน /app"

echo "--- Containers ---"
docker ps -a

echo "--- Listening web ports ---"
ss -tulpn | grep -E ':(80|443|3000|8080)\b' || echo "ไม่พบพอร์ตเว็บที่คุ้นเคย"
