#!/bin/bash
# รันบน VM เครื่อง 3 (Deploy Target) หลัง ssh เข้าไปแล้ว
set -euo pipefail

APP_DIR="/app"

echo "=== [เครื่อง 3] Deploy Target Install ==="

# 1. Base packages
echo "[1] ลง git, curl, openssh-server..."
sudo apt-get update -y
sudo apt-get install -y git curl wget ca-certificates openssh-server
sudo systemctl enable --now ssh

# 2. Docker
echo "[2] ลง Docker..."
if ! command -v docker >/dev/null 2>&1; then
    curl -fsSL https://get.docker.com | sudo sh
fi
sudo systemctl enable --now docker

if ! docker compose version >/dev/null 2>&1; then
    sudo apt-get install -y docker-compose-plugin
fi

# ให้ user ปัจจุบันรัน docker ได้โดยไม่ต้อง sudo (สำคัญ เพราะ CI จะ ssh มาสั่ง docker compose ตรงๆ)
sudo usermod -aG docker "$USER"

# 3. เตรียม /app ให้พร้อมรับไฟล์จาก pipeline
echo "[3] เตรียมโฟลเดอร์ $APP_DIR ..."
sudo mkdir -p "$APP_DIR"
sudo chown "$USER":"$USER" "$APP_DIR"

# ใส่ docker-compose.yml เปล่าๆ ไว้ก่อน กัน pipeline รอบแรก fail เพราะไม่มีไฟล์
if [ ! -f "$APP_DIR/docker-compose.yml" ]; then
    cat > "$APP_DIR/docker-compose.yml" <<'EOF'
# ไฟล์นี้จะถูกแทนที่ด้วยของจริงตอน push code ผ่าน pipeline
# ใส่ placeholder ไว้กันสคริปต์ deploy fail เพราะหาไฟล์ไม่เจอ
services:
  placeholder:
    image: nginx:alpine
EOF
    echo "    -> สร้าง $APP_DIR/docker-compose.yml (placeholder) แล้ว"
fi

echo "[+] เครื่อง 3 พร้อมแล้ว"
docker --version
docker compose version
echo ""
echo "[!] หมายเหตุ: ต้อง logout/login (หรือ 'newgrp docker') ให้สิทธิ์ docker group มีผล"
