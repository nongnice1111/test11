# DevOps Competition — Install Scripts (Final)

เฉพาะสคริปต์ "ติดตั้ง" เท่านั้น ไม่มี automation/emergency เสริม
ต้องเข้าใจทุกคำสั่งที่รัน ห้ามพึ่งสคริปต์อย่างเดียว

## ลำดับการใช้งาน

### ก่อนเริ่ม
แก้ค่าใน `config.env` ให้ตรงกับโจทย์จริง (TPL_ID, VMID, IP)

### เครื่อง 1 — Proxmox Host
```
bash 01-proxmox/install.sh
```
รอ output บอก IP ของเครื่อง 2, 3 → กรอกลง `config.env`
ถ้าพัง: `bash 01-proxmox/rollback.sh <VMID>`

### เครื่อง 2 — GitLab Server (SSH เข้าไปก่อน)
```
bash 02-gitlab-server/install.sh
bash 02-gitlab-server/check.sh
```
รอจนสคริปต์บอก "GitLab ตอบสนองแล้ว" ก่อนเข้าเว็บ
Password ตอน login ครั้งแรกสคริปต์จะพิมพ์ให้ท้ายผลลัพธ์

### เครื่อง 3 — Deploy Target (SSH เข้าไปก่อน)
```
bash 03-deploy-target/install.sh
bash 03-deploy-target/check.sh
```
สคริปต์เตรียม `/app` + docker-compose.yml placeholder ไว้ให้แล้ว
กันไม่ให้ pipeline รอบแรก fail เพราะหาไฟล์ไม่เจอ

### โน้ตบุ๊กทีม (Windows) — ไม่ใช่เครื่องแข่ง
```
04-windows-client/install.ps1
```
ได้ public key มา → เอาไปวางใน GitLab: Preferences > SSH Keys

## หลังจากนี้ (ทำเอง ไม่มีสคริปต์)
- เขียน `.gitlab-ci.yml` ที่ root ของโปรเจกต์
- ใส่ SSH_PRIVATE_KEY ใน GitLab CI/CD Variables (type: File)
- push code แล้วดู pipeline รัน
- ถ้า fail: อ่าน log ท้ายๆ ก่อนเสมอ ห้ามเดา

ดู `04-windows-client/quick-reference.txt` สำหรับคำสั่งที่ต้องพิมพ์คล่องมือ
