#!/bin/bash
# รันบนเครื่อง Proxmox Host เท่านั้น (หลังลง Proxmox VE จาก ISO เสร็จแล้ว)
# ก่อนรัน: แก้ค่าใน ../config.env ให้ตรงกับโจทย์ก่อน
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$SCRIPT_DIR/../config.env"

echo "=== [เครื่อง 1] Proxmox Install/Provision ==="

# 0. เช็คว่ารันบน Proxmox จริง
if ! command -v qm >/dev/null 2>&1; then
    echo "[ERROR] ไม่เจอคำสั่ง qm — เครื่องนี้ไม่ใช่ Proxmox host"
    exit 1
fi

# 1. เช็ค template มีจริงไหม
echo "[1] เช็ค Template VMID=$TPL_ID ..."
if ! qm status "$TPL_ID" >/dev/null 2>&1; then
    echo "[ERROR] ไม่เจอ Template $TPL_ID"
    echo "        รัน 'qm list' เพื่อดูว่ามี template ตัวไหนบ้าง"
    echo "        ถ้ายังไม่มี template เลย ต้องสร้างเองก่อน (ลง OS + qm template)"
    exit 1
fi

# 2. เช็คว่า VMID ที่จะ clone ชนกับของเดิมไหม
for id in "$VM_GITLAB" "$VM_DEPLOY"; do
    if qm status "$id" >/dev/null 2>&1; then
        echo "[ERROR] VMID $id มีอยู่แล้ว ตรวจสอบก่อนว่าใช่ของเก่าที่ยังไม่ลบหรือเปล่า"
        exit 1
    fi
done

# 3. Clone VM ทั้งสองตัว
echo "[2] Clone GitLab VM ($VM_GITLAB)..."
qm clone "$TPL_ID" "$VM_GITLAB" --name "$GITLAB_NAME" --full

echo "[3] Clone Deploy VM ($VM_DEPLOY)..."
qm clone "$TPL_ID" "$VM_DEPLOY" --name "$DEPLOY_NAME" --full

# 4. Start
echo "[4] Start VMs..."
qm start "$VM_GITLAB"
qm start "$VM_DEPLOY"

echo "[5] รอบูต 20 วิ..."
sleep 20

qm status "$VM_GITLAB"
qm status "$VM_DEPLOY"

# 5. ดึง IP
echo "[6] ดึง IP (ถ้า Guest Agent ยังไม่ตอบ ให้เข้า VM รัน 'ip a' เอง)"
echo "--- GitLab VM ---"
qm guest cmd "$VM_GITLAB" network-get-interfaces 2>/dev/null || echo "Guest Agent ยังไม่พร้อม ลองใหม่อีกสักครู่"
echo "--- Deploy VM ---"
qm guest cmd "$VM_DEPLOY" network-get-interfaces 2>/dev/null || echo "Guest Agent ยังไม่พร้อม ลองใหม่อีกสักครู่"

echo ""
echo "[!] อย่าลืมกรอก IP ที่ได้ลงใน config.env (IP_GITLAB / IP_DEPLOY) และจดใส่กระดาษ"

# 6. Snapshot กันพัง
echo "[7] ถ่าย snapshot เริ่มต้น..."
qm snapshot "$VM_GITLAB" init-clean --description "Fresh boot from template"
qm snapshot "$VM_DEPLOY" init-clean --description "Fresh boot from template"

echo "[+] เครื่อง 1 พร้อมแล้ว"
