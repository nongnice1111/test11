#!/bin/bash
# ใช้เมื่อ VM พังกลางแข่ง ต้องการย้อนกลับไปจุด snapshot init-clean
# วิธีใช้: bash rollback.sh 101   (หรือ 102)
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$SCRIPT_DIR/../config.env"

VMID="${1:-}"
if [ -z "$VMID" ]; then
    echo "ใช้: bash rollback.sh <VMID>"
    echo "เช่น: bash rollback.sh $VM_GITLAB"
    exit 1
fi

echo "[!] กำลัง rollback VM $VMID กลับไปจุด init-clean..."
qm rollback "$VMID" init-clean
qm start "$VMID"
echo "รอบูต 15 วิ..."
sleep 15
qm status "$VMID"
echo "[+] เสร็จแล้ว ลอง ssh เข้าใหม่อีกครั้ง"
