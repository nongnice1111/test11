#!/bin/bash
echo "=== [เครื่อง 2] GitLab Health Check ==="

command -v git >/dev/null 2>&1 && echo "✓ Git ติดตั้งแล้ว" || echo "✗ ไม่มี Git"
command -v docker >/dev/null 2>&1 && echo "✓ Docker ติดตั้งแล้ว" || echo "✗ ไม่มี Docker"
systemctl is-active --quiet docker && echo "✓ Docker กำลังรัน" || echo "✗ Docker ไม่ทำงาน"
docker compose version >/dev/null 2>&1 && echo "✓ Docker Compose ติดตั้งแล้ว" || echo "✗ ไม่มี Docker Compose"

docker ps --format '{{.Names}}' | grep -qx gitlab && echo "✓ GitLab container กำลังรัน" || echo "✗ GitLab container ไม่ทำงาน"

echo "--- ตอบ HTTP ไหม ---"
curl -s -o /dev/null -w "HTTP status: %{http_code}\n" http://localhost || echo "เชื่อมต่อไม่ได้"

echo "--- Containers ---"
docker ps -a

echo "--- Listening ports ---"
ss -tulpn | grep -E ':(80|443|2224)\b' || echo "ไม่พบพอร์ต GitLab"
