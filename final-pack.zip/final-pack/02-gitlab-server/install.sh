#!/bin/bash
# รันบน VM เครื่อง 2 (GitLab Server) หลัง ssh เข้าไปแล้ว
set -euo pipefail

echo "=== [เครื่อง 2] GitLab Server Install ==="

# 1. Base packages
echo "[1] ลง git, curl, openssh-server..."
sudo apt-get update -y
sudo apt-get install -y git curl wget ca-certificates openssh-server
sudo systemctl enable --now ssh

# 2. Docker
echo "[2] ลง Docker..."
if ! command -v docker >/dev/null 2>&1; then
    curl -fsSL https://get.docker.com | sudo sh
fi
sudo systemctl enable --now docker

if ! docker compose version >/dev/null 2>&1; then
    sudo apt-get install -y docker-compose-plugin
fi

# 3. เตรียมไฟล์ GitLab
echo "[3] เตรียม docker-compose.yml สำหรับ GitLab..."
sudo mkdir -p /opt/gitlab
sudo tee /opt/gitlab/docker-compose.yml > /dev/null <<'EOF'
services:
  gitlab:
    image: gitlab/gitlab-ce:latest
    container_name: gitlab
    restart: always
    hostname: gitlab
    shm_size: "256m"
    ports:
      - "80:80"
      - "443:443"
      - "2224:22"
    volumes:
      - ./config:/etc/gitlab
      - ./logs:/var/log/gitlab
      - ./data:/var/opt/gitlab
EOF

# 4. Start GitLab
echo "[4] Start GitLab container (ครั้งแรกอาจใช้เวลาหลายนาที)..."
cd /opt/gitlab
sudo docker compose up -d

# 5. รอจน GitLab ตอบสนองจริง (ไม่ใช่แค่ container ขึ้น)
echo "[5] รอ GitLab พร้อมใช้งาน (เช็คทุก 10 วิ นานสุด 5 นาที)..."
for i in $(seq 1 30); do
    if curl -s -o /dev/null -w "%{http_code}" http://localhost | grep -qE "200|302"; then
        echo "    -> GitLab ตอบสนองแล้ว!"
        break
    fi
    echo "    ยังไม่พร้อม รอต่อ... ($((i*10)) วิ)"
    sleep 10
done

# 6. ดึง root password เริ่มต้น
echo "[6] Root password เริ่มต้น (ใช้ล็อกอินครั้งแรก username: root):"
sudo docker exec gitlab grep 'Password:' /etc/gitlab/initial_root_password 2>/dev/null || \
    echo "    ยังดึงไม่ได้ ลองรันเองอีกครั้ง: sudo docker exec gitlab grep 'Password:' /etc/gitlab/initial_root_password"

echo ""
echo "[+] เครื่อง 2 พร้อมแล้ว — เข้าเว็บที่ http://<IP เครื่องนี้>"
docker --version
docker compose version
