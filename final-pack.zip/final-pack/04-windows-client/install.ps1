# รันบนโน้ตบุ๊ก Windows ของทีมเราเองเท่านั้น (ไม่ใช่เครื่องแข่งที่จะกลายเป็น Proxmox)

Write-Host "=== [Windows Client] Setup ==="

# 1. Git identity (ถามชื่อจริง กันสับสนเวลามีหลายเครื่อง/หลายคน commit)
$gitName = Read-Host "ใส่ชื่อสำหรับ git commit (เช่น ชื่อเล่นหรือชื่อทีม)"
if ([string]::IsNullOrWhiteSpace($gitName)) { $gitName = "DevOpsTeam" }
git config --global user.name "$gitName"
git config --global user.email "devops@competition.local"
Write-Host "ตั้ง git identity เป็น: $gitName"

# 2. SSH key
$sshDir = Join-Path $env:USERPROFILE ".ssh"
New-Item -ItemType Directory -Force $sshDir | Out-Null
$key = Join-Path $sshDir "id_ed25519"

if (!(Test-Path $key)) {
    ssh-keygen -t ed25519 -N '""' -f $key -C "$gitName-laptop"
} else {
    Write-Host "มี SSH key อยู่แล้วที่ $key (ไม่สร้างใหม่)"
}

Write-Host ""
Write-Host "=== PUBLIC KEY: เอาไปวางใน GitLab -> Preferences -> SSH Keys ==="
Get-Content "$key.pub"
Write-Host "================================================================"

# 3. เตือนขั้นตอนต่อไป
Write-Host ""
Write-Host "ขั้นต่อไป (ทำเอง ไม่ใช่สคริปต์):"
Write-Host "1) วาง public key ด้านบนใน GitLab: Preferences > SSH Keys > ลบ Expiration date"
Write-Host "2) แก้ ~/.ssh/config เพิ่ม Host shortcut (proxmox / gitlab / deploy) เพื่อพิมพ์สั้นลง"
Write-Host "3) ทดสอบ: ssh -p 2224 -i `"$key`" git@<GITLAB_IP>"
